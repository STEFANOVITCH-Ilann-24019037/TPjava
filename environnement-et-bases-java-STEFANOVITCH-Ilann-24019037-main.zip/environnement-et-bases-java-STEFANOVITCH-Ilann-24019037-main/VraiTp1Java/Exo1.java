package fr.Ilann.Tp1;

public class Tp1{

	public static void main (String [] args) {
		System.out.println("coucou");
	}
}

