public class Exo5{



public static void main(String [] args) {
		int number1 = 11, number2 = 22, number3 = 33, number4 = 44, number5 = 55,product;
		product = number1 * number2 * number3 * number4 * number5 ;
		System.out.println(" La somme est : " + product );
		
	}
}
