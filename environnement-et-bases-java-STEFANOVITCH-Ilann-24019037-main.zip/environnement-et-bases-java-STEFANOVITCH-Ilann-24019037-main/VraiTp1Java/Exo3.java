
public class Exo3{

public static void main(String [] args) {
		int number1 = 11, number2 = 22, number3 = 33, number4 = 44, number5 = 55,number6 = 66,sum;
		sum = number1 + number2 +number3 + number4 +number5 + number6;
		System.out.println(" La somme est : " + sum );
		
	}
}
