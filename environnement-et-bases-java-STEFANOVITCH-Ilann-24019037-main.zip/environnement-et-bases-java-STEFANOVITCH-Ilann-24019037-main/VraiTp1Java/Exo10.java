import java.util.Scanner;

public class exo10 {
   public static void main(String[] args) {
      int jour = 0;

      System.out.println("taper un nombre associé a un jour :  ");
        Scanner s = new Scanner(System.in);
        jour = s.nextInt();

      if ( jour == 1 )
        {
         System.out.println( "Lundi" );
        }
         else if (jour == 2)
        {
         System.out.println ("Mardi" );
        }
         else if (jour == 3)
        {
         System.out.println ("Mercredi" );
        }
         else if (jour == 4)
        {
         System.out.println ("Jeudi" );
        }
         else if (jour == 5)
        {
         System.out.println ("Vendredi" );
        }
         else if (jour == 6)
        {
         System.out.println ("Samedi" );
        }
         else if (jour == 7)
        {
         System.out.println ("Dimanche" );
        }
         else
        {
         System.out.println ("ceci n'est pas un nombre associé à un jour");
        }

   }
}
