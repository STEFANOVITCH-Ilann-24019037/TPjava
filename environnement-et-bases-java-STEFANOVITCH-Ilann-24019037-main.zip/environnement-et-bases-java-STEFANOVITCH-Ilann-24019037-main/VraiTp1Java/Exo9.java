import java.util.Scanner;

public class exo7 {
   public static void main(String[] args) {
      int marque = 50;
      System.out.println("La marque est de :  " + marque);
      Scanner s = new Scanner(System.in);
        marque = s.nextInt();

      if ( marque % 2 == 0 ) 
        {
         System.out.println( " la marque est pair" );
        }
         else 
        {
         System.out.println (" la marque est impair" );
        }
   }
}
