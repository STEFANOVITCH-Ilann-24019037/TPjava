public class Exo6{

public static void main(String[] args) {
		double area,perimeter,length = 15,width =10;
		perimeter = length * 2 + width * 2 ;
		area = width*length;
		System.out.println("the area is : " + area + " the perimeter is : " + perimeter );
		
	}

}
