package tp3exosYaip6;

abstract public interface Movable {
	
	abstract void moveUp();
	abstract void moveDown();
	abstract void moveLeft();
	abstract void moveRight();
}
