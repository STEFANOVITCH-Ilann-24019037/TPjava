package tp3exosYaip6;

abstract public interface GeometricObject {

	 double getArea();
	 double getPerimeter();
}
