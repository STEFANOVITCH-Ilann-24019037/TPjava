package exodebug;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EtudiantTest {

    Etudiant unEtudiant;
    
    @BeforeEach
    public void setUp() {
        unEtudiant = new Etudiant("Sophie");
        Matiere escalade = new Matiere("Escalade", 0.15, 0.85);
        Matiere anglais = new Matiere("Anglais", 0.35, 0.65);
        Matiere tddJava = new Matiere("TDD en Java", 0.25, 0.75);
        unEtudiant.noter(escalade, 8.0, 5.0); // 5.45
        unEtudiant.noter(anglais, 17.0, 19.0); // 18.3
        unEtudiant.noter(tddJava, 15.0, 6.0); // 8.25
    }

    @Test
    public void doitRetournerLaMoyenne() {
        double expected = 10.67;
        assertEquals(expected, unEtudiant.getMoyenne(), 0.01);
    }

    @Test
    public void doitRetournerUneRepresentationTextuelleDEtudiant() {
        String texteEtudiant = "L'étudiant(e) Sophie a pour moyenne 10.67";
        assertEquals(texteEtudiant, unEtudiant.toString());
    }
}

