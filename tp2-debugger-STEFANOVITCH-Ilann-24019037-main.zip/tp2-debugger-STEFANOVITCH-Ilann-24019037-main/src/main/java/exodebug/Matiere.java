package exodebug;

public class Matiere {

	private String nom;
	private double coeffET;
	private double coeffTP;

	public Matiere(String nom, double coeffET, double coeffTP) {
		this.nom = nom;
		this.coeffET = coeffET;
		this.coeffTP = coeffTP;
	}

	public double getCoeffET() {
		return coeffET;
	}

	public double getCoeffTP() {
		return coeffTP;
	}

}
