package exodebug;

import java.util.LinkedHashSet;
import java.util.Set;

public class Etudiant {
	
	private String nom;
	private Set<Note> notes = new LinkedHashSet<>();
	
	public Etudiant(String nom) {
		this.nom = nom;
	}

	public void noter(Matiere matiere, double noteExamenTerminal, double noteTravauxPratiques) {
		Note note = new Note(matiere, noteExamenTerminal, noteTravauxPratiques);
		notes.add(note);
	}

	public double getMoyenne() {
		double moyenneGenerale = 0.0;
		for(Note note : notes) {
			moyenneGenerale += note.getMoyenne();
		}
		moyenneGenerale /= notes.size();
		return moyenneGenerale;
	}

	@Override
	public String toString() {
		return "L'étudiant(e) " + nom + "a pour moyenne " + String.format("%.2f", getMoyenne());
	}
}
