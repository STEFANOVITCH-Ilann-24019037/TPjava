package exodebug;

public class Note {
	private Matiere matiere;
	private double noteExamenTerminal, noteTravauxPratiques;

	public Note(Matiere matiere, double noteExamenTerminal, double noteTravauxPratiques) {
		this.matiere = matiere;
		this.noteExamenTerminal = noteExamenTerminal;
		this.noteTravauxPratiques = noteTravauxPratiques;
	}

    double getMoyenne() {
		return (matiere.getCoeffET() * noteExamenTerminal + matiere.getCoeffTP() * noteTravauxPratiques) / 2;
    }

}
