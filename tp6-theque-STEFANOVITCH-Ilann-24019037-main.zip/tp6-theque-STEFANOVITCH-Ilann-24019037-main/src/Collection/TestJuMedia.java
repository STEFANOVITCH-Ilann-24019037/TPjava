package Collection;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.*;

public class TestJuMedia {

    private Mediatheque mediatheque;
    private Document doc1, doc2, doc3;

    @BeforeEach
    public void setUp() {
        doc1 = new Document("Zebra");
        doc2 = new Document("Apple");
        doc3 = new Document("Mango");

        List<Document> docs = new ArrayList<>(Arrays.asList(doc1, doc2, doc3));
        mediatheque = new Mediatheque(docs);
    }

    @Test
    public void testGetDocuments() {
        Collection<Document> documents = mediatheque.getDocuments();
        assertNotNull(documents);
        assertEquals(3, documents.size());
        assertTrue(documents.contains(doc1));
        assertTrue(documents.contains(doc2));
        assertTrue(documents.contains(doc3));
    }

    @Test
    public void testSetDocuments() {
        Document doc4 = new Document("Banana");
        List<Document> newDocs = new ArrayList<>(Collections.singletonList(doc4));
        mediatheque.setDocuments(newDocs);
        assertEquals(1, mediatheque.getDocuments().size());
        assertTrue(mediatheque.getDocuments().contains(doc4));
    }

    @Test
    public void testToString() {
        String expected = "Mediatheque : [Zebra, Apple, Mango]";
        assertEquals(expected, mediatheque.toString());
    }

    @Test
    public void testTrierDocuments() {
        mediatheque.trierDocuments();
        List<Document> sortedDocs = new ArrayList<>(mediatheque.getDocuments());
        assertEquals("Apple", sortedDocs.get(0).getTitre());
        assertEquals("Mango", sortedDocs.get(1).getTitre());
        assertEquals("Zebra", sortedDocs.get(2).getTitre());
    }
}