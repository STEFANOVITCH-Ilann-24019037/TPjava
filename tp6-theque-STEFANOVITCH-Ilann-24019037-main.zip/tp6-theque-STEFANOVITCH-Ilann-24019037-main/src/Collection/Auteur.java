package Collection;
public class Auteur extends Personne {
    public Auteur(String prenom, String nom, String email) {
        super(prenom, nom, email);
    }

}
