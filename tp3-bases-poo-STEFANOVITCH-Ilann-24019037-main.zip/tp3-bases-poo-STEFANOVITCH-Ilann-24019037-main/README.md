# R201 DOO : squelette de structure pour projet eclipse Java

Noter :
- le fichier caché <code>.gitignore</code>, qui liste les fichiers que Git NE doit PAS versionner. 
Ne pas modifier ce fichier.
- le fichier caché <code>.classpath</code>
- le dossier <code>src/</code>
- le fichier <code>src/.gitignore</code> (identique au <code>.gitignore</code> à la racine)

##Modifier par Ilann Stefanovitch
