package exoEngins;

class Eolienne extends Propulsion {

    //Pas demander mais fait quand même
    public Eolienne() {
    }

    //Mes Fonction
    @Override
    public double consommerEnergie( ) {
        return 0;
    }
    @Override
    public String toString() {
        return "Eolienne []";
    }
}
