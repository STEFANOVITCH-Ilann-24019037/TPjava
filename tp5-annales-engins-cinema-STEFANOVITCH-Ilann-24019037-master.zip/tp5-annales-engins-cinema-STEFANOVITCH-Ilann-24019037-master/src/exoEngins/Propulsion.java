package exoEngins;

abstract class Propulsion {
    public abstract double consommerEnergie();
}
